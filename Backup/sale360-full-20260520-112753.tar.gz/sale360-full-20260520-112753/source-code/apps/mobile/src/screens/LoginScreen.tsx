import { useState } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet,
  KeyboardAvoidingView, Platform, Alert, ActivityIndicator,
} from 'react-native';
import { useStore } from '../stores/useStore';

const API_URL = process.env.EXPO_PUBLIC_API_URL || 'http://localhost:3001';

export function LoginScreen() {
  const setAuth = useStore((s) => s.setAuth);
  const deviceId = useStore((s) => s.deviceId);

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [mode, setMode] = useState<'password' | 'pin'>('password');

  const handleLogin = async () => {
    if (!email.trim()) {
      Alert.alert('Erro', 'Digite seu email');
      return;
    }

    setLoading(true);
    try {
      const endpoint = mode === 'pin'
        ? `${API_URL}/api/auth/login-pin`
        : `${API_URL}/api/auth/login`;

      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: email.trim(),
          [mode === 'pin' ? 'pin' : 'password']: password,
          deviceId,
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        Alert.alert('Erro', data.error || 'Falha no login');
        return;
      }

      setAuth({
        token: data.token,
        user: data.user,
        tenant: data.tenant,
      });
    } catch (err: any) {
      Alert.alert('Erro', 'Sem conexão com o servidor. Verifique sua internet.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <View style={styles.header}>
        <Text style={styles.logo}>S360</Text>
        <Text style={styles.subtitle}>PDV Inteligente</Text>
      </View>

      <View style={styles.form}>
        <Text style={styles.title}>
          {mode === 'pin' ? 'Login Rápido' : 'Entrar'}
        </Text>

        <TextInput
          style={styles.input}
          placeholder="Email"
          placeholderTextColor="#64748B"
          value={email}
          onChangeText={setEmail}
          autoCapitalize="none"
          keyboardType="email-address"
        />

        <TextInput
          style={styles.input}
          placeholder={mode === 'pin' ? 'PIN (4 dígitos)' : 'Senha'}
          placeholderTextColor="#64748B"
          value={password}
          onChangeText={setPassword}
          secureTextEntry
          maxLength={mode === 'pin' ? 4 : undefined}
          keyboardType={mode === 'pin' ? 'number-pad' : 'default'}
        />

        <TouchableOpacity
          style={[styles.button, loading && styles.buttonDisabled]}
          onPress={handleLogin}
          disabled={loading}
        >
          {loading ? (
            <ActivityIndicator color="#fff" />
          ) : (
            <Text style={styles.buttonText}>Entrar</Text>
          )}
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.toggle}
          onPress={() => setMode(mode === 'pin' ? 'password' : 'pin')}
        >
          <Text style={styles.toggleText}>
            {mode === 'pin' ? 'Usar senha' : 'Usar PIN rápido'}
          </Text>
        </TouchableOpacity>
      </View>

      <Text style={styles.version}>Sale360 v0.1.0</Text>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0F172A',
    justifyContent: 'center',
    padding: 24,
  },
  header: {
    alignItems: 'center',
    marginBottom: 48,
  },
  logo: {
    fontSize: 48,
    fontWeight: '900',
    color: '#6366F1',
    letterSpacing: 2,
  },
  subtitle: {
    fontSize: 16,
    color: '#94A3B8',
    marginTop: 4,
  },
  form: {
    backgroundColor: '#1E293B',
    borderRadius: 16,
    padding: 24,
  },
  title: {
    fontSize: 20,
    fontWeight: '700',
    color: '#F1F5F9',
    marginBottom: 20,
    textAlign: 'center',
  },
  input: {
    backgroundColor: '#0F172A',
    borderRadius: 12,
    padding: 16,
    fontSize: 16,
    color: '#F1F5F9',
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#334155',
  },
  button: {
    backgroundColor: '#6366F1',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    marginTop: 8,
  },
  buttonDisabled: {
    opacity: 0.6,
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '700',
  },
  toggle: {
    marginTop: 16,
    alignItems: 'center',
  },
  toggleText: {
    color: '#6366F1',
    fontSize: 14,
  },
  version: {
    textAlign: 'center',
    color: '#475569',
    marginTop: 32,
    fontSize: 12,
  },
});
